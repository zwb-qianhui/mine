#!/bin/bash
#Timu.txt储存题目 xx.txt储存选项 daan.txt储存答案 fushu.txt储存每一题的分数 cs.txt储存一些参数 lx.txt储存题目类型
#cs.txt 第一行储存一共有多少道题 第二行储存哪道题分数最低
hx1='请问练习的类型是?
a:所有 p:配置文件 d:端口 m:命令 b:变量 c:操作 f:服务 b:报错 o:其它
'
fenshu(){
b=`awk "NR==1" cs.txt`
for i in `seq $b`
do
        f[i]=`awk "NR==$i" fenshu.txt`
done
}
lianxi (){
clear
if [ -z "$1" ];then
	echo 进入练习模式
	read -p "$hx1" t
else
	t=$1
fi
fenshu
a=$RANDOM
b=`awk "NR==1" cs.txt`
if [ $t == a ];then
        if [ $a -gt 32600 ];then
        a=`awk "NR==2" cs.txt`
        awk "NR==$a" Timu.txt
        awk "NR==$a" xx.txt
        read -p "输入你的答案" udaan
        zdaan=`awk "NR==$a" daan.txt`
                if [ $udaan == $zdaan ];then
                        echo yes
                        let f[a]++
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                else
                        echo "正确答案是$zdaan"
                        let f[a]--
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                fi
        else
		d=$[32768%b]
                e=$RANDOM
                while [ $e -lt $d ]
                do
                        e=$RANDOM
                done
                a=$[e%b+1]
                awk "NR==$a" Timu.txt
                awk "NR==$a" xx.txt
                read -p "输入你的答案" udaan
                zdaan=`awk "NR==$a" daan.txt`
                if [ $udaan == $zdaan ];then
                        echo yes
                        let f[a]++
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                else
                        echo "正确答案是$zdaan"
                        let f[a]--
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                fi
	fi
#如果增加新的类型,复制从此开始59行,并更改2个p为相应类型
elif [ $t == p ];then
	if [ $a -gt 32600 ];then
	a=`awk "NR==2" cs.txt`
	awk "NR==$a" Timu.txt
	awk "NR==$a" xx.txt
	read -p "输入你的答案" udaan
	zdaan=`awk "NR==$a" daan.txt`
		if [ $udaan == $zdaan ];then
			echo yes
			let f[a]++
			echo ${f[1]} > fenshu.txt
			for i in `seq 2 $b`
			do
				echo ${f[i]} >>fenshu.txt
			done
		else
			echo "正确答案是$zdaan"
        	        let f[a]--
                	echo ${f[1]} > fenshu.txt
                	for i in `seq 2 $b`
                	do      
                        	echo ${f[i]} >>fenshu.txt
			done
		fi
	else
		c=`awk "NR==$a{print}" lx.txt`
		while [ "$c" != p ]
		do
			d=$[32768%b]
			e=$RANDOM
			while [ $e -lt $d ]
			do
				e=$RANDOM
			done
			a=$[e%b+1]
			c=`awk "NR==$a{print}" lx.txt`
		done
	        awk "NR==$a" Timu.txt
		awk "NR==$a" xx.txt
        	read -p "输入你的答案" udaan
        	zdaan=`awk "NR==$a" daan.txt`
                if [ $udaan == $zdaan ];then
                        echo yes
                        let f[a]++
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                else
                        echo "正确答案是$zdaan"
                        let f[a]--
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                fi
	fi
#到此结束
elif [ $t == o ];then
	if [ $a -gt 32600 ];then
	a=`awk "NR==2" cs.txt`
	awk "NR==$a" Timu.txt
	awk "NR==$a" xx.txt
	read -p "输入你的答案" udaan
	zdaan=`awk "NR==$a" daan.txt`
		if [ $udaan == $zdaan ];then
			echo yes
			let f[a]++
			echo ${f[1]} > fenshu.txt
			for i in `seq 2 $b`
			do
				echo ${f[i]} >>fenshu.txt
			done
		else
			echo "正确答案是$zdaan"
        	        let f[a]--
                	echo ${f[1]} > fenshu.txt
                	for i in `seq 2 $b`
                	do      
                        	echo ${f[i]} >>fenshu.txt
			done
		fi
	else
		c=`awk "NR==$a{print}" lx.txt`
		while [ "$c" != o ]
		do
			d=$[32768%b]
			e=$RANDOM
			while [ $e -lt $d ]
			do
				e=$RANDOM
			done
			a=$[e%b+1]
			c=`awk "NR==$a{print}" lx.txt`
		done
	        awk "NR==$a" Timu.txt
		awk "NR==$a" xx.txt
        	read -p "输入你的答案" udaan
        	zdaan=`awk "NR==$a" daan.txt`
                if [ $udaan == $zdaan ];then
                        echo yes
                        let f[a]++
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                else
                        echo "正确答案是$zdaan"
                        let f[a]--
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                fi
	fi
elif [ $t == f ];then
	if [ $a -gt 32600 ];then
	a=`awk "NR==2" cs.txt`
	awk "NR==$a" Timu.txt
	awk "NR==$a" xx.txt
	read -p "输入你的答案" udaan
	zdaan=`awk "NR==$a" daan.txt`
		if [ $udaan == $zdaan ];then
			echo yes
			let f[a]++
			echo ${f[1]} > fenshu.txt
			for i in `seq 2 $b`
			do
				echo ${f[i]} >>fenshu.txt
			done
		else
			echo "正确答案是$zdaan"
        	        let f[a]--
                	echo ${f[1]} > fenshu.txt
                	for i in `seq 2 $b`
                	do      
                        	echo ${f[i]} >>fenshu.txt
			done
		fi
	else
		c=`awk "NR==$a{print}" lx.txt`
		while [ "$c" != f ]
		do
			d=$[32768%b]
			e=$RANDOM
			while [ $e -lt $d ]
			do
				e=$RANDOM
			done
			a=$[e%b+1]
			c=`awk "NR==$a{print}" lx.txt`
		done
	        awk "NR==$a" Timu.txt
		awk "NR==$a" xx.txt
        	read -p "输入你的答案" udaan
        	zdaan=`awk "NR==$a" daan.txt`
                if [ $udaan == $zdaan ];then
                        echo yes
                        let f[a]++
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                else
                        echo "正确答案是$zdaan"
                        let f[a]--
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                fi
	fi
elif [ $t == c ];then
	if [ $a -gt 32600 ];then
	a=`awk "NR==2" cs.txt`
	awk "NR==$a" Timu.txt
	awk "NR==$a" xx.txt
	read -p "输入你的答案" udaan
	zdaan=`awk "NR==$a" daan.txt`
		if [ $udaan == $zdaan ];then
			echo yes
			let f[a]++
			echo ${f[1]} > fenshu.txt
			for i in `seq 2 $b`
			do
				echo ${f[i]} >>fenshu.txt
			done
		else
			echo "正确答案是$zdaan"
        	        let f[a]--
                	echo ${f[1]} > fenshu.txt
                	for i in `seq 2 $b`
                	do      
                        	echo ${f[i]} >>fenshu.txt
			done
		fi
	else
		c=`awk "NR==$a{print}" lx.txt`
		while [ "$c" != c ]
		do
			d=$[32768%b]
			e=$RANDOM
			while [ $e -lt $d ]
			do
				e=$RANDOM
			done
			a=$[e%b+1]
			c=`awk "NR==$a{print}" lx.txt`
		done
	        awk "NR==$a" Timu.txt
		awk "NR==$a" xx.txt
        	read -p "输入你的答案" udaan
        	zdaan=`awk "NR==$a" daan.txt`
                if [ $udaan == $zdaan ];then
                        echo yes
                        let f[a]++
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                else
                        echo "正确答案是$zdaan"
                        let f[a]--
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                fi
	fi
elif [ $t == b ];then
	if [ $a -gt 32600 ];then
	a=`awk "NR==2" cs.txt`
	awk "NR==$a" Timu.txt
	awk "NR==$a" xx.txt
	read -p "输入你的答案" udaan
	zdaan=`awk "NR==$a" daan.txt`
		if [ $udaan == $zdaan ];then
			echo yes
			let f[a]++
			echo ${f[1]} > fenshu.txt
			for i in `seq 2 $b`
			do
				echo ${f[i]} >>fenshu.txt
			done
		else
			echo "正确答案是$zdaan"
        	        let f[a]--
                	echo ${f[1]} > fenshu.txt
                	for i in `seq 2 $b`
                	do      
                        	echo ${f[i]} >>fenshu.txt
			done
		fi
	else
		c=`awk "NR==$a{print}" lx.txt`
		while [ "$c" != b ]
		do
			d=$[32768%b]
			e=$RANDOM
			while [ $e -lt $d ]
			do
				e=$RANDOM
			done
			a=$[e%b+1]
			c=`awk "NR==$a{print}" lx.txt`
		done
	        awk "NR==$a" Timu.txt
		awk "NR==$a" xx.txt
        	read -p "输入你的答案" udaan
        	zdaan=`awk "NR==$a" daan.txt`
                if [ $udaan == $zdaan ];then
                        echo yes
                        let f[a]++
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                else
                        echo "正确答案是$zdaan"
                        let f[a]--
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                fi
	fi
elif [ $t == m ];then
	if [ $a -gt 32600 ];then
	a=`awk "NR==2" cs.txt`
	awk "NR==$a" Timu.txt
	awk "NR==$a" xx.txt
	read -p "输入你的答案" udaan
	zdaan=`awk "NR==$a" daan.txt`
		if [ $udaan == $zdaan ];then
			echo yes
			let f[a]++
			echo ${f[1]} > fenshu.txt
			for i in `seq 2 $b`
			do
				echo ${f[i]} >>fenshu.txt
			done
		else
			echo "正确答案是$zdaan"
        	        let f[a]--
                	echo ${f[1]} > fenshu.txt
                	for i in `seq 2 $b`
                	do      
                        	echo ${f[i]} >>fenshu.txt
			done
		fi
	else
		c=`awk "NR==$a{print}" lx.txt`
		while [ "$c" != m ]
		do
			d=$[32768%b]
			e=$RANDOM
			while [ $e -lt $d ]
			do
				e=$RANDOM
			done
			a=$[e%b+1]
			c=`awk "NR==$a{print}" lx.txt`
		done
	        awk "NR==$a" Timu.txt
		awk "NR==$a" xx.txt
        	read -p "输入你的答案" udaan
        	zdaan=`awk "NR==$a" daan.txt`
                if [ $udaan == $zdaan ];then
                        echo yes
                        let f[a]++
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                else
                        echo "正确答案是$zdaan"
                        let f[a]--
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                fi
	fi
elif [ $t == d ];then
	if [ $a -gt 32600 ];then
	a=`awk "NR==2" cs.txt`
	awk "NR==$a" Timu.txt
	awk "NR==$a" xx.txt
	read -p "输入你的答案" udaan
	zdaan=`awk "NR==$a" daan.txt`
		if [ $udaan == $zdaan ];then
			echo yes
			let f[a]++
			echo ${f[1]} > fenshu.txt
			for i in `seq 2 $b`
			do
				echo ${f[i]} >>fenshu.txt
			done
		else
			echo "正确答案是$zdaan"
        	        let f[a]--
                	echo ${f[1]} > fenshu.txt
                	for i in `seq 2 $b`
                	do      
                        	echo ${f[i]} >>fenshu.txt
			done
		fi
	else
		c=`awk "NR==$a{print}" lx.txt`
		while [ "$c" != d ]
		do
			d=$[32768%b]
			e=$RANDOM
			while [ $e -lt $d ]
			do
				e=$RANDOM
			done
			a=$[e%b+1]
			c=`awk "NR==$a{print}" lx.txt`
		done
	        awk "NR==$a" Timu.txt
		awk "NR==$a" xx.txt
        	read -p "输入你的答案" udaan
        	zdaan=`awk "NR==$a" daan.txt`
                if [ $udaan == $zdaan ];then
                        echo yes
                        let f[a]++
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                else
                        echo "正确答案是$zdaan"
                        let f[a]--
                        echo ${f[1]} > fenshu.txt
                        for i in `seq 2 $b`
                        do
                                echo ${f[i]} >>fenshu.txt
                        done
                fi
	fi
fi
read -p "是否继续y/n
" k
if [ $k == y ];then
	lianxi $t
else
	min=${f[1]}
	m=`awk "NR==2" cs.txt`
	for i in `seq $b`
	do
		if [ $min -gt ${f[i]} ];then
			min=${f[i]}
			m=$i
		fi
	done
	sed -i "2s/[0-9]*/$m/" cs.txt
	echo 再见
fi
}
add (){
fenshu
echo -e "进入添加模式"
read -p "请输入题目
" t
read -p "请输入选项
a:" a
read -p "请输入选项
b:" b
read -p "请输入选项
c:" c
read -p "请输入选项
d:" d
read -p "正确答案是:" z
read -p "设置初始分数为" f
read -p "$hx1" l
echo $t >> Timu.txt
echo "a:$a b:$b c:$c d:$d" >> xx.txt
echo "$z" >> daan.txt
echo "$f" >> fenshu.txt
echo "$l" >> lx.txt
m=`sed -n '1p' cs.txt`
x=`sed -n '2p' cs.txt`
min=${f[x]}
let m++
sed -i "1s/[0-9]*/$m/" cs.txt
if [ $f -lt $min ];then
	sed -i "2s/[0-9]*/$m/" cs.txt
fi
}
tixi(){
b=`awk "NR==1" cs.txt`
echo 以下题目是否需要进行更新
for i in `seq $b`
do
        f[i]=`awk "NR==$i" fenshu.txt`
	if [ ${f[i]} -gt 100 ];then
		echo "第$i题"
	fi
done
}
if [ $# -eq 0 ];then
	lianxi
elif [ $1 == l ];then
	lianxi
elif [ $1 == a ];then
	add
elif [ $1 == t ];then
	tixi
elif [ $1 == --help ];then
	echo 'a:添加模式,t:提醒模式,l:练习模式'
fi
