#!/bin/bash
a=`awk 'BEGIN{a=0}/a/{a++}END{print a}' daan.txt`
b=`awk 'BEGIN{a=0}/b/{a++}END{print a}' daan.txt`
c=`awk 'BEGIN{a=0}/c/{a++}END{print a}' daan.txt`
d=`awk 'BEGIN{a=0}/d/{a++}END{print a}' daan.txt`
echo a有$a个
echo b有$b个
echo c有$c个
echo d有$d个
